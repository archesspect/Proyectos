package colecciones;
import clases.Votante;
import clases.Direcciones;
import java.util.*;
import clases.FiltroSedes;
import clases.Sedes;

public class ColeccionSedes implements FiltroSedes {

    private Direcciones d;
    private Sedes sedes;
    private ArrayList<Sedes> sede;

    public ColeccionSedes() {
        sede = new ArrayList<>();
        sedes = new Sedes();
        llenado();

    }

    @Override
    public final void llenado() {
        Sedes s = new Sedes();
        s.setNombreSede("Liceo de Limache");
        s.setUbicacionSede("Riquelme 133");
        s.setCapacidadDeLocal(100);
        agregar(s);
        Sedes ss = new Sedes();
        ss.setNombreSede("Escuela Basica Brasilia");
        ss.setUbicacionSede("Av José Tomás Urmeneta 599 ");
        ss.setCapacidadDeLocal(100);
        agregar(ss);
        Sedes sss = new Sedes();
        sss.setNombreSede("Escuela N 49 Colegio Italiano");
        sss.setUbicacionSede("12 de Febrero 173 ");
        sss.setCapacidadDeLocal(100);
        agregar(sss);
        Sedes ssss = new Sedes();
        ssss.setNombreSede("Escuela Coeduc Teniente Hernán Merino Correa");
        ssss.setUbicacionSede("Sargento Aldea 357");
        ssss.setCapacidadDeLocal(100);
        agregar(ssss);

    }

    public void agregar(Sedes s) {
        sede.add(s);
    }

    public boolean agregar(Votante nuevoVotante, String nombreCalle, String numero, String rut, String esVocal) {
        d = new Direcciones();
        String x;
        if (d.BuscarLiceoDeLimache(nombreCalle) == true) {
            x = "Liceo de Limache";
            for (int i = 0; i < sede.size(); i++) {
                if (sede.get(i).getNombreSede().equals(x)) {
                    if (sede.get(i).agregar(nuevoVotante, rut, esVocal) == true) {
                        return true;
                    }
                }
            }
        } else if (d.BuscarColegioItaliano(nombreCalle) == true) {
            x = "Escuela N 49 Colegio Italiano";
            for (int i = 0; i < sede.size(); i++) {
                if (sede.get(i).getNombreSede().equals(x)) {
                    if (sede.get(i).agregar(nuevoVotante, rut, esVocal) == true) {
                        return true;
                    }
                }
            }
        } else if (d.BuscarEscuelaBasicaBrasilia(nombreCalle) == true) {
            x = "Escuela Basica Brasilia";
            for (int i = 0; i < sede.size(); i++) {
                if (sede.get(i).getNombreSede().equals(x)) {
                    if (sede.get(i).agregar(nuevoVotante, rut, esVocal) == true) {
                        return true;
                    }
                }
            }
        } else if (d.BuscarEscuelaTenienteHernánMerinoCorrea(nombreCalle) == true) {
            x = "Escuela Coeduc Teniente Hernán Merino Correa";
            for (int i = 0; i < sede.size(); i++) {
                if (sede.get(i).getNombreSede().equals(x)) {
                    if (sede.get(i).agregar(nuevoVotante, rut, esVocal) == true) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean modificarCapSede(int cap, String nombreS) {
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).getNombreSede().equals(nombreS)) {
                sede.get(i).setCapacidadDeLocal(cap);
                return true;
            }
        }
        return false;
    }

    public boolean modificarDireccion(String ubicacion, String nombreS) {
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).getNombreSede().equals(nombreS)) {
                sede.get(i).setUbicacionSede(ubicacion);
                return true;
            }
        }
        return false;
    }

    public boolean modificarNombre(String rutVotante, String nuevoNombre) {

        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).obtenerVotante(rutVotante) == true) {
                sede.get(i).modificarNombre(rutVotante, nuevoNombre);
                return true;
            }
        }
        return false;
    }

    public boolean modificarRut(String rutVotante, String nuevoRut) {
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).obtenerVotante(rutVotante) == true) {
                sede.get(i).modificarRut(rutVotante, nuevoRut);
                return true;
            }
        }
        return false;
    }

    public boolean modificarDireccion(String rutVotante, String nuevaDireccion, String nuevoNumero) {
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).obtenerVotante(rutVotante) == true) {
                sede.get(i).modificarUbicacion(rutVotante, nuevaDireccion);
                return true;
            }
        }
        return false;
    }

    public boolean modificarEsVocal(String rutVotante, String esVocal) {
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).obtenerVotante(rutVotante) == true) {
                sede.get(i).modificarVocal(rutVotante, esVocal);
                return true;
            }
        }
        return false;
    }

    public boolean eliminar(String rutVotante) {
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).obtenerVotante(rutVotante) == true) {
                sede.get(i).eliminar(rutVotante);
                return true;
            }

        }
        return false;
    }

    public void mostrar() {
        sedes.mostrar();
    }
    
    public void mostrar(int opcion) {
        String s;
        switch (opcion) {
            case 1:
                s = "Liceo de Limache";
                break;
            case 2:
                s = "Escuela Basica Brasilia";
                break;
            case 3:
                s = "Escuela N 49 Colegio Italiano";
                break;
            case 4:
                s = " Escuela Coeduc Teniente Hernán Merino Correa";
                break;
            default:
                s = "";
                break;
        }
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).getNombreSede().equals(s)) {
                sede.get(i).mostrarV();

            }
        }
    }
    
    public void mostrarV( String rut) {
        for (int i = 0; i < sede.size(); i++) {
            if (sede.get(i).obtenerVotante(rut) == true) {
                sede.get(i).esVocal(rut);
            }
        }    
    }

    public void capacitacionesV(String opcion) {
        sedes.capacitacionesV();
    }

    public void capacitacionesA(String opcion) {
        sedes.capacitacionesA();
    }

    public void menorPorcentaje() {
        
        sedes.menorPorcentaje();
    }

    public void porcentaje(String opcion) { 
        sedes.porcentaje();
    }

    public ArrayList<Sedes> getSede() {
        return sede;
    }

    public void setSede(ArrayList<Sedes> sede) {
        this.sede = sede;
    }

}
 