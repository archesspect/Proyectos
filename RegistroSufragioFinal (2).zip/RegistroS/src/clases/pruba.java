package clases;
import clases.Sedes;
import clases.Votante;
import colecciones.ColeccionSedes;
import clases.Direcciones;
import java.io.IOException;
import java.util.Scanner;

public class pruba {
    

    public static void main(String[] args) throws IOException {
        //prueba();
        Votante v = new Votante();
        Sedes s = new Sedes();
        ColeccionSedes se= new ColeccionSedes();
        agregar(v);
        
    }
        public static String leerString() throws IOException {
        Scanner hh = new Scanner(System.in);
        String variable = hh.nextLine();
        return variable;
    }

    public static int leerInt() throws IOException {
        Scanner hh = new Scanner(System.in);
        int variable = hh.nextInt();
        return variable;
    }
        public static void agregar(Votante v) throws IOException {
        Votante vo = new Votante();
        ColeccionSedes se = new ColeccionSedes();
        System.out.println("Ingrese el nombre Completo del nuevo votante");
        String nombrePersona = leerString();
        vo.setNombrePersona(nombrePersona);
        System.out.println("Ingrese el RUT del votante");
        String rutPersona = leerString();
        vo.setRutPersona(rutPersona);
        System.out.println("Ingrese el nombre de la Calle o Avenida (Av) del votante");
        String calle = leerString();
        vo.setCallePersona(calle);
        System.out.println("Ingrese el número de domicilio del votante");
        String numero = leerString();
        vo.setNumeroCasaPersona(numero);
        System.out.println("¿Este votante es Vocal de mesa? Presione 1 si lo es o 2 si no");
        String esVocal = leerString();
        vo.setEsVocal(esVocal);
        if (se.agregar(vo, calle, numero, rutPersona, esVocal) == true) {
            System.out.println("Votante agregado con éxito");
        } else {
            System.out.println("Local de votación inexistente o votante ya inscrito, revise los datos ingresados");
        }
    }
        



    /*public static void prueba() throws IOException {

        Votante vo = new Votante();
        System.out.println("Ingrese el nombre Completo del nuevo votante");
        String nombrePersona = leerString();
        vo.setNombrePersona(nombrePersona);
        System.out.println("Ingrese el RUT del votante");
        String rutPersona = leerString();
        vo.setRutPersona(rutPersona);
        System.out.println("Ingrese el nombre de la Calle o Avenida (Av) del votante");
        String calle = leerString();
        vo.setCallePersona(calle);
        System.out.println("Ingrese el número de domicilio del votante");
        String numero = leerString();
        vo.setNumeroCasaPersona(numero);
        System.out.println("¿Este votante es Vocal de mesa? Presione 1 si lo es o 2 si no");
        String esVocal = leerString();
        vo.setEsVocal(esVocal);
        //agregar funcion es vocal

        if (vo.agregar(vo, calle,numero, rutPersona, esVocal) == true) {

            System.out.println("Votante agregado con éxito");

        } else {
            System.out.println("Local de votación inexistente o votante ya inscrito, revise los datos ingresados");
        }

    }*/
}
