package clases;

public abstract class Persona {
    private String nombrePersona;
    private String callePersona;
    private String numeroCasaPersona;
    private String rutPersona;
    String esVocal;
    public Persona() {
        nombrePersona = "";
        callePersona = "";
        rutPersona = "";
        esVocal = "";
        numeroCasaPersona = "";
    }
    // GETTER & SETTER   
    public String getNombrePersona() {
        return nombrePersona;
    }
    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }
    public String getCallePersona() {
        return callePersona;
    }
    public void setCallePersona(String callePersona) {
        this.callePersona = callePersona;
    }
    public String getNumeroCasaPersona() {
        return numeroCasaPersona;
    }
    public void setNumeroCasaPersona(String numeroCasaPersona) {
        this.numeroCasaPersona = numeroCasaPersona;
    }
    public String getRutPersona() {
        return rutPersona;
    }
    public void setRutPersona(String rutPersona) {
        this.rutPersona = rutPersona;
    }
    public String getEsVocal() {
        return esVocal;
    }
    public void setEsVocal(String esVocal) {
        this.esVocal = esVocal;
    }
    public abstract boolean eliminar( String rut);
    public abstract boolean modificar(String rut, String nombreS);
    public abstract boolean modificarRut(String antiguoRut, String nuevoRut);
    public abstract boolean modificar(String rutVotante, String nuevaCalle, String nuevoNumero);
    public abstract boolean modificarVocal(String rutPersona, String esVocal);
    public abstract void esVocal(String rutPersona);
}
