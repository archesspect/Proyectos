package clases;

import java.util.HashMap;

public class Vocal extends Persona {

    private HashMap<String, Votante> esVocalXRut;

    public Vocal() {
        super();
        esVocalXRut = new HashMap<>();
    }

    @Override
    public boolean eliminar(String rut) {
        for (int i = 0; i < esVocalXRut.size(); i++) {
            if (esVocalXRut.get(i).getRutPersona().equals(rut)) {
                esVocalXRut.remove(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean modificar(String rut, String nombreS) {
        esVocalXRut.get(rut).setNombrePersona(nombreS);
        return false;
    }

    @Override
    public boolean modificarRut(String antiguoRut, String nuevoRut) {
        esVocalXRut.get(antiguoRut).setRutPersona(nuevoRut);
        return true;
    }

    @Override
    public boolean modificar(String rutVotante, String nuevaCalle, String nuevoNumero) {
        esVocalXRut.get(rutVotante).setCallePersona(nuevaCalle);
        esVocalXRut.get(rutVotante).setNumeroCasaPersona(nuevoNumero);
        return true;
    }

    @Override
    public void esVocal(String rutPersona) {
        for (int i = 0; i < esVocalXRut.size(); i++) {
            if (esVocalXRut.get(i).getRutPersona().equals(rutPersona)) {
                esVocal = esVocalXRut.get(i).getEsVocal();
                if (esVocal.equals("3")) {
                    System.out.print("El votante de RUT " + rutPersona + " no es vocal de mesa ni apoderado de mesa");
                } else if (esVocal.equals("1")) {
                    System.out.print("El votante de RUT " + rutPersona + "es vocal de mesa");

                } else if (esVocal.equals("2")){
                    System.out.print("El votante de RUT " + rutPersona + "es apoderado de mesa");
                }
            }
        }
    }

    @Override
    public boolean modificarVocal(String rutPersona, String esVocal) {
        esVocalXRut.get(rutPersona).setEsVocal(esVocal);
        return true;
    }

    public void agregar(String esVocal, Votante nuevoVotante) {
        esVocalXRut.put(esVocal, nuevoVotante);
    }

    public void capacitacionV() {
        for (int i = 0; i < esVocalXRut.size(); i++) {
            if (esVocalXRut.get(i).getEsVocal().equals("1")){
                System.out.println("NOMBRE: " + esVocalXRut.get(i).getNombrePersona() + "\n"
                                + "RUT: " + esVocalXRut.get(i).getRutPersona() + "\n"
                                + "DIRECCION: Calle: " + esVocalXRut.get(i).getCallePersona() + " Número: "+esVocalXRut.get(i).getNumeroCasaPersona()
                                + "Tiene capacitación el día 5 de diciembre a las 08:00 am en su respectivo local de votación");
            }
    }
    }

    public void capacitacionA() {
    for (int i = 0; i < esVocalXRut.size(); i++) {
            if (esVocalXRut.get(i).getEsVocal().equals("2")){
                System.out.println("NOMBRE: " + esVocalXRut.get(i).getNombrePersona() + "\n"
                                + "RUT: " + esVocalXRut.get(i).getRutPersona() + "\n"
                                + "DIRECCION: Calle: " + esVocalXRut.get(i).getCallePersona() + " Número: "+esVocalXRut.get(i).getNumeroCasaPersona()
                                + "Tiene capacitación el día 5 de diciembre a las 08:00 am en su respectivo local de votación");
            }
    }
    }
}
