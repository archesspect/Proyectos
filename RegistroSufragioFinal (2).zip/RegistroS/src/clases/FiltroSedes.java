package clases;

public interface FiltroSedes {

    public void llenado();

    
}
