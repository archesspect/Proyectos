package clases;

import java.util.ArrayList;

public class Direcciones implements FiltroSedes {

    private ArrayList<String> liceoDeLimache = new ArrayList<>();
    private ArrayList<String> escuelaBasicaBrasilia = new ArrayList();
    private ArrayList<String> colegioItaliano = new ArrayList();
    private ArrayList<String> escuelaTenienteHernánMerinoCorrea = new ArrayList();

    public Direcciones() {
        llenado();
        
    }
    @Override
    public final void llenado() {
        liceoDeLimache.add(0, "Agustin Garaventa");
        liceoDeLimache.add(1, "Pedro de Valdivia");
        liceoDeLimache.add(2, "Asunción");
        liceoDeLimache.add(3, "Bogotá");
        liceoDeLimache.add(4, "Brasilia");
        liceoDeLimache.add(5, "Buenos Aires");
        liceoDeLimache.add(6, "Carlos Ponce");
        liceoDeLimache.add(7, "Carrera");
        liceoDeLimache.add(8, "Doña Palmira");
        liceoDeLimache.add(9, "Emilio Pomar");

        escuelaBasicaBrasilia.add(0, "Alfredo Nazar");
        escuelaBasicaBrasilia.add(1, "Pasaje la Greda");
        escuelaBasicaBrasilia.add(2, "Pasaje Malbec");
        escuelaBasicaBrasilia.add(3, "Profesor Jorge Lillo");
        escuelaBasicaBrasilia.add(4, "Padre Hurtado");
        escuelaBasicaBrasilia.add(5, "Condell");
        escuelaBasicaBrasilia.add(6, "Caupolicán");
        escuelaBasicaBrasilia.add(7, "Carelmapu");
        escuelaBasicaBrasilia.add(8, "Carmen Quiroga de Urmeneta");
        escuelaBasicaBrasilia.add(9, "Baquedano");

        colegioItaliano.add(0, "La Viña");
        colegioItaliano.add(1, "Av Concepción");
        colegioItaliano.add(2, "Av Independencia");
        colegioItaliano.add(3, "Calle los Capachitos");
        colegioItaliano.add(4, "Pasaje los Gladiolos");
        colegioItaliano.add(5, "Pasaje Manuel Rojas");
        colegioItaliano.add(6, "Pasaje Patricio Linch");
        colegioItaliano.add(7, "Quillayes");
        colegioItaliano.add(8, "Santiago Bueras");
        colegioItaliano.add(9, "Vallenar");

        escuelaTenienteHernánMerinoCorrea.add(0, "18 de Septiembre");
        escuelaTenienteHernánMerinoCorrea.add(1, "Andrés Bello");
        escuelaTenienteHernánMerinoCorrea.add(2, "Calle Manao");
        escuelaTenienteHernánMerinoCorrea.add(3, "La Palma");
        escuelaTenienteHernánMerinoCorrea.add(4, "Pasaje Ancud");
        escuelaTenienteHernánMerinoCorrea.add(5, "Rupanco");
        escuelaTenienteHernánMerinoCorrea.add(6, "Pasaje Lota");
        escuelaTenienteHernánMerinoCorrea.add(7, "Pasaje Medialuna");
        escuelaTenienteHernánMerinoCorrea.add(8, "Mistral");
        escuelaTenienteHernánMerinoCorrea.add(9, "Calle Freirina");
    }
    public boolean BuscarEscuelaBasicaBrasilia(String calle) {
        for (int i = 0; i <= escuelaBasicaBrasilia.size(); i++) {
            if (escuelaBasicaBrasilia.get(i).equals(calle)) {
                return true;
            }
        }
        return false;
    }

    public boolean BuscarColegioItaliano(String calle) {
        for (int i = 0; i <= colegioItaliano.size(); i++) {
            if (colegioItaliano.get(i).equals(calle)) {
                return true;
            }
        }
        return false;
    }

    public boolean BuscarEscuelaTenienteHernánMerinoCorrea(String calle) {
        for (int i = 0; i <= escuelaTenienteHernánMerinoCorrea.size(); i++) {
            if (escuelaTenienteHernánMerinoCorrea.get(i).equals(calle)) {
                return true;
            }
        }
        return false;
    }

    public boolean BuscarLiceoDeLimache(String calle) {
        for (int i = 0; i <= liceoDeLimache.size(); i++) {
            if (liceoDeLimache.get(i).equals(calle)) {
                return true;
            }
        }
        return false;
    }

    public ArrayList ArraylistEscuelaBasicaBrasilia() {
        return escuelaBasicaBrasilia;
    }

    public ArrayList ArraylistColegioItaliano() {
        return colegioItaliano;
    }

    public ArrayList ArraylistEscuelaTenienteHernánMerinoCorrea() {
        return escuelaTenienteHernánMerinoCorrea;
    }

    public ArrayList<String> getLiceoDeLimache() {
        return liceoDeLimache;
    }

    public void setLiceoDeLimache(ArrayList<String> liceoDeLimache) {
        this.liceoDeLimache = liceoDeLimache;
    }

    public ArrayList<String> getEscuelaBasicaBrasilia() {
        return escuelaBasicaBrasilia;
    }

    public void setEscuelaBasicaBrasilia(ArrayList<String> escuelaBasicaBrasilia) {
        this.escuelaBasicaBrasilia = escuelaBasicaBrasilia;
    }

    public ArrayList<String> getColegioItaliano() {
        return colegioItaliano;
    }

    public void setColegioItaliano(ArrayList<String> colegioItaliano) {
        this.colegioItaliano = colegioItaliano;
    }

    public ArrayList<String> getEscuelaTenienteHernánMerinoCorrea() {
        return escuelaTenienteHernánMerinoCorrea;
    }

    public void setEscuelaTenienteHernánMerinoCorrea(ArrayList<String> escuelaTenienteHernánMerinoCorrea) {
        this.escuelaTenienteHernánMerinoCorrea = escuelaTenienteHernánMerinoCorrea;
    }
}
