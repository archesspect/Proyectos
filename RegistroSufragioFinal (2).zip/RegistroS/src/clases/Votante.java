package clases;

import java.util.ArrayList;
import java.util.List;
import clases.Vocal;

public class Votante extends Persona {
    private ArrayList<Votante> votantes;
    private Vocal v;

    public Votante() {
        super();
        votantes = new ArrayList<>();
        v = new Vocal();

    }

    @Override
    public boolean eliminar(String rut) {
        if (votantes.isEmpty()) {
            return false;
        } else {
            for (int i = 0; i < votantes.size(); i++) {
                if (votantes.get(i).getRutPersona().equals(rut)) {
                    votantes.remove(i);
                    v.eliminar(rut);
                    return true;
                }
            }
            return false;
        }
    }

    @Override
    public boolean modificar(String rut, String nombreS) {
        if (votantes.isEmpty()) {
            return false;
        } else {
            for (int i = 0; i < votantes.size(); i++) {
                if (votantes.get(i).getRutPersona().equals(rut)) {
                    votantes.get(i).setNombrePersona(nombreS);
                    v.modificar(rut, nombreS);
                    return true;
                }
            }
            return false;
        }
    }

    @Override
    public boolean modificar(String rutVotante, String nuevaCalle, String nuevoNumero) {
        if (votantes.isEmpty()) {
            return false;
        } else {
            for (int i = 0; i <= votantes.size(); i++) {
                if (votantes.get(i).getRutPersona().equals(rutVotante)) {
                    votantes.get(i).setCallePersona(nuevaCalle);
                    votantes.get(i).setNumeroCasaPersona(nuevoNumero);
                    v.modificar(rutVotante, nuevaCalle, nuevoNumero);
                    return true;
                }
            }
            return false;
        }
    }

    @Override
    public boolean modificarRut(String antiguoRut, String nuevoRut) {
        if (votantes.isEmpty()) {
            return false;
        } else {
            for (int i = 0; i < votantes.size(); i++) {
                if (votantes.get(i).getRutPersona().equals(antiguoRut)) {
                    votantes.get(i).setRutPersona(nuevoRut);
                    v.modificarRut(antiguoRut, nuevoRut);
                    return true;
                }
            }
            return false;
        }
    }

    @Override
    public void esVocal(String rutPersona) {
        if (votantes.isEmpty()) {
            System.out.print("No hay votantes en esta sede! revisa los datos ingresados");
        } else {
            v.esVocal(rutPersona);
        }
    }

    @Override
    public boolean modificarVocal(String rutPersona, String esVocal) {
        if (votantes.isEmpty()) {
            return false;
        } else {
            if (v.modificarVocal(rutPersona, esVocal) == true) {
                return true;
            }
        }
        return false;
    }

    public boolean obtener(String rut) {
        for (int i = 0; i <= votantes.size(); i++) {
            if (votantes.get(i).getRutPersona().equals(rut)) {
                return true;
            }
        }
        return false;
    }

    public boolean agregar(Votante nuevoVotante, String rut, String esVocal) {
        if (votantes.isEmpty()) {
            votantes.add(nuevoVotante);
            v.agregar(esVocal, nuevoVotante);
            return true;
        } else {
            for (int i = 0; i < votantes.size(); i++) {
                if (votantes.get(i).getRutPersona().equals(rut)) {
                    return false;
                }
            }
            votantes.add(nuevoVotante);
            v.agregar(esVocal, nuevoVotante);
            return true;
        }
    }

    public void mostrarV() {
        if (votantes.isEmpty()) {
            System.out.println("No hay votantes pertenecientes a esta sede");
        } else {
            for (int i = 0; i < votantes.size(); i++) {
                System.out.println("Nombre: " + votantes.get(i).getNombrePersona()
                        + "\nRUT: " + votantes.get(i).getRutPersona()
                        + "\nDirección: Calle: " + votantes.get(i).getCallePersona() + " Número: " + votantes.get(i).getNumeroCasaPersona());

            }
        }
    }

    public int sizeVotantes() {
        int num = 0;
        if (votantes.isEmpty()) {
            return num;
        } else {
            for (int i = 0; i <= votantes.size(); i++) {
                num++;
            }
            return num;
        }

    }

    public void capacitacionV() {

    }

    public void capacitacionA() {

    }
}
