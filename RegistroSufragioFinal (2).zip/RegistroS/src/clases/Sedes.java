package clases;

import clases.Direcciones;
import clases.Votante;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;

public class Sedes {
    private Votante votante;
    private ArrayList<Sedes> sede;
    private Direcciones d;
    private String nombreSede;
    private String ubicacionSede;
    private int capacidadDeLocal;

    public Sedes() {
        d = new Direcciones();
        votante = new Votante();
        nombreSede = "";
        ubicacionSede = "";
        capacidadDeLocal = 0;
    }

    public boolean obtenerVotante(String rut) {
        if (votante.obtener(rut) == true) {
            return true;
        }
        return false;
    }

    //AGREGAR VOTANTE A UNA SEDE
    public boolean agregar(Votante nuevoVotante, String rut, String esVocal) {
        if (votante.agregar(nuevoVotante, rut, esVocal) == true) {
            return true;
        }
        return false;
    }

    //ELIMINAR VOTANTE DE UNA SEDE
    public boolean eliminar(String ruts) {
        if(votante.eliminar(ruts)==true){
            return true;
        }
        return false;
    }

    //MODIFICAR DATOS DE UN VOTANTE PERTENECIENTE A UNA SEDE
    //MODIFICA NOMBRE 
    public boolean modificarNombre(String rutVotante, String nuevoNombre) {
        if(votante.modificar(rutVotante, nuevoNombre)==true){
            return true;
        }
        return false;
    }

    //MODIFICA EL RUT
    public boolean modificarRut(String antiguoRut, String nuevoRut) {
        if (votante.modificarRut(antiguoRut, nuevoRut)== true){
            return true;
        }
        return false;
    }
    //MODIFICA LA UBICACION
    public boolean modificarUbicacion(String rutVotante, String nuevaUbi) {
        if (votante.modificar(rutVotante, nuevaUbi) == true){
            return true;
        }
        return false;
    }

    public boolean modificarVocal(String rutPersona, String esVocal) {
        if (votante.modificarVocal(rutPersona, esVocal)== true){
            return true;
        }
        return false;
    }
    public void mostrar() {
        for(int i = 0 ; i <= sede.size();i++){
            System.out.println("Nombre Sede: " + sede.get(i).getNombreSede()
                        + "\nDirección : " + sede.get(i).getUbicacionSede()
                        + "\nCapacidad: Calle" +sede.get(i).getCapacidadDeLocal());
        }
    }
    public void mostrarV() {
        votante.mostrarV();
    }

    public boolean esVocal(String rut) {
        votante.esVocal(rut);
        return true;
    }

    public void menorPorcentaje() {
        int size = votante.sizeVotantes();
        int s = sede.get(0).getCapacidadDeLocal();
        int resultado = ((size * 100)/s);
        int s1 = sede.get(1).getCapacidadDeLocal();
        int resultado1 = ((size * 100)/s1);
        int s2 = sede.get(2).getCapacidadDeLocal();
        int resultado2 = ((size * 100)/s2);
        int s3 = sede.get(3).getCapacidadDeLocal();
        int resultado3 = ((size * 100)/s3);
        
            if (resultado < resultado1) {
                if(resultado < resultado2){
                    if (resultado < resultado3){
                        System.out.print("La sede "+sede.get(0).getNombreSede()+ "tiene la menor ocupación con un " +resultado+ "% de ocupación");
                    }
                }
            }
            if (resultado1 < resultado) {
                if(resultado1 < resultado2){
                    if (resultado1 < resultado3){
                        System.out.print("La sede "+sede.get(1).getNombreSede()+ "tiene la menor ocupación con un " +resultado1+ "% de ocupación");
                    }
                }
            }
            if (resultado2 < resultado) {
                if(resultado2 < resultado){
                    if (resultado < resultado3){
                        System.out.print("La sede "+sede.get(2).getNombreSede()+ "tiene la menor ocupación con un " +resultado2+ "% de ocupación");
                    }
                }
            }
            if (resultado3 < resultado) {
                if(resultado3 < resultado1){
                    if (resultado3 < resultado2){
                        System.out.print("La sede "+sede.get(3).getNombreSede()+ "tiene la menor ocupación con un " +resultado3+ "% de ocupación");
                    }
                }
            }
    }
    public void porcentaje() {
        int size = votante.sizeVotantes();
        for(int i = 0; i <= sede.size();i++){
           int s = sede.get(i).getCapacidadDeLocal();
           int resultado = ((size * 100)/s);
            System.out.print("La ocupacion del local es de " + resultado + "%"
                          +"hay "+size+" votantes registrados de un total de "+s);
        }
        
    }

    public void capacitacionesV() {
        votante.capacitacionV();
    }
    public void capacitacionesA() {
        votante.capacitacionA();
    }
    

    //Getter & Setters
    public String getNombreSede() {
        return nombreSede;
    }

    public void setNombreSede(String nombreSede) {
        this.nombreSede = nombreSede;
    }

    public String getUbicacionSede() {
        return ubicacionSede;
    }

    public void setUbicacionSede(String ubicacionSede) {
        this.ubicacionSede = ubicacionSede;
    }

    public int getCapacidadDeLocal() {
        return capacidadDeLocal;
    }

    public void setCapacidadDeLocal(int capacidadDeLocal) {
        this.capacidadDeLocal = capacidadDeLocal;
    }

}
