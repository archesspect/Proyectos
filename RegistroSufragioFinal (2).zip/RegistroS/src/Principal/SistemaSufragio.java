package Principal;

import clases.Votante;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.IOException;
import colecciones.ColeccionSedes;

public class SistemaSufragio {

    public static void main(String[] args) throws IOException {
        ColeccionSedes cs = new ColeccionSedes();
        Scanner sn = new Scanner(System.in);
        boolean salir;
        int opcion = 0;
        int opcion1 = 0;
        int opcion2 = 0;
        int opcion3 = 0;
        int opcion4 = 0;
        int opcion5 = 0;
        int opcion6 = 0;
        do {
            System.out.println("Ingrese un numero del 1-6 \n"
                    + "1.- Añadir Un nuevo votante\n"
                    + "2.- Modificar Datos\n"
                    + "3.- Eliminar Datos\n"
                    + "4.- Mostrar Datos\n"
                    + "5.- Calcular Ocupación de un local\n"
                    + "6.- Revisar fecha de capacitaciones para los vocales de mesa\n"
                    + "7.- SALIR");
            salir = true;
            try {
                opcion = sn.nextInt();
                switch (opcion) {
                    case 1:
                        SistemaSufragio.agregar(cs);
                        break;
                    case 2:
                        System.out.println("¿Que deseas modificar?\n"
                                + "1.- Modificar datos de un local de votacion\n"
                                + "2.- Modificar datos de un votante\n"
                                + "3.- Modificar datos de un vocal\n"
                                + "4.- Presione 4 para salir");
                        opcion1 = sn.nextInt();
                        switch (opcion1) {
                            case 1:
                                System.out.println("¿Que deseas modificar?\n"
                                        + "1.- Modificar capacidad de un local de votación\n"
                                        + "2.- Modificar ubicación de un local de votación\n"
                                        + "3.- Presione 3 para salir");
                                opcion4 = sn.nextInt();

                                switch (opcion4) {

                                    case 1:
                                        SistemaSufragio.modificarCapacidadSede(cs);
                                        break;
                                    case 2:
                                        SistemaSufragio.modificarDireccion(cs);
                                        break;
                                    case 3:
                                        salir = true;
                                        break;
                                }
                                break;
                            case 2:
                                System.out.println("¿Que deseas modificar?\n"
                                        + "1.- Modificar nombre de un votante\n"
                                        + "2.- Modificar RUT de un votante\n"
                                        + "3.- Modificar dirección de un votante\n"
                                        + "4.- Modificar si es vocal o no lo es\n"
                                        + "5.- Presione 4 para salir");
                                opcion4 = sn.nextInt();
                                switch (opcion4) {
                                    case 1:
                                        SistemaSufragio.modificarNombre(cs);
                                        break;
                                    case 2:
                                        SistemaSufragio.modificarRut(cs);
                                        break;
                                    case 3:
                                        SistemaSufragio.modificarDireccionP(cs);
                                        break;
                                    case 4:
                                        SistemaSufragio.modificarEsVocal(cs);
                                        break;
                                    case 5:
                                        salir = true;
                                        break;
                                }
                                break;
                            case 3:
                                System.out.println("¿Que deseas modificar?\n"
                                        + "1.- Modificar nombre de un vocal\n"
                                        + "2.- Modificar RUT de un vocal\n"
                                        + "3.- Modificar dirección de un vocal\n"
                                        + "4.- Cambiar si ya no es vocal"
                                        + "5.- Presione 4 para salir");
                                opcion4 = sn.nextInt();

                                switch (opcion4) {
                                    case 1:
                                        SistemaSufragio.modificarNombre(cs);
                                        break;
                                    case 2:
                                        SistemaSufragio.modificarRut(cs);
                                        break;
                                    case 3:
                                        SistemaSufragio.modificarDireccionP(cs);
                                        break;
                                    case 4:
                                        SistemaSufragio.modificarEsVocal(cs);
                                        break;
                                    case 5:
                                        salir = true;
                                        break;
                                }
                                break;
                            case 4:
                                salir = true;
                                break;
                            default:
                                if (opcion1 < 1 && opcion1 > 5) {
                                    System.out.println("Porfavor insertar numeros entre el 1 y 5");
                                }
                                break;
                        }
                        break;
                    case 3:
                        System.out.println("¿ Que deseas eliminar?\n"
                                + "1.- Eliminar votante\n"
                                + "2.- Eliminar un Vocal\n"
                                + "3.- Presione 3 para salir");
                        opcion2 = sn.nextInt();
                        switch (opcion2) {
                            case 1:
                                SistemaSufragio.eliminar(cs);
                                break;
                            case 2:
                               SistemaSufragio.eliminarP(cs);
                                break;
                            case 3:
                                salir = true;
                                break;
                            default:
                                if (opcion2 < 1 && opcion2 > 3) {
                                    System.out.println("Porfavor insertar numeros entre el 1 y 3");
                                }
                                break;
                        }
                        break;
                    case 4:
                        System.out.println("¿Que deseas mostrar?\n"
                                + "1.- Mostrar Locales de votación\n"
                                + "2.- Mostrar votantes por sede\n"
                                + "3.- Mostrar si un votante es vocal de mesa o apoderado de mesa\n"
                                + "4.- Presione 4 para salir");
                        opcion3 = sn.nextInt();
                        switch (opcion3) {
                            case 1:
                               SistemaSufragio.mostrar(cs);
                                break;
                            case 2:
                               SistemaSufragio.mostrarP(cs);
                                break;
                            case 3:
                               SistemaSufragio.mostrarV(cs);
                                break;
                            case 4:
                                salir = true;
                                break;
                            default:
                                if (opcion3 < 1 && opcion3 > 4) {
                                    System.out.println("Porfavor insertar numeros entre el 1 y 4");
                                }
                                break;
                        }
                        break;
                    case 5:
                        System.out.println("¿Qué desea calcular?\n"
                                + "1.- Buscar el local con menor ocupación\n"
                                + "2.-Calcular el porcentaje de ocupación de local de votación");
                        opcion5 = sn.nextInt();
                        switch (opcion5) {
                            case 1:
                               SistemaSufragio.menorPorcentaje(cs);
                                break;
                            case 2:
                                SistemaSufragio.porcentajeT(cs);
                                break;
                            default:
                                if (opcion5 < 1 && opcion5 > 2) {
                                    System.out.println("Porfavor seleccione 1 o 2");
                                }
                                break;
                        }
                        break;
                    case 6:
                        System.out.println("¿Qué capacitación desea ver?\n"
                                + "1.- Capacitacion de los vocales de mesa de una sede\n"
                                + "2.-Capacitacion de los apoderados de mesa de una sede");
                        opcion6 = sn.nextInt();
                        switch (opcion6) {
                            case 1:
                               SistemaSufragio.capacitacionesV(cs);
                                break;
                            case 2:
                                SistemaSufragio.capacitacionesA(cs);
                                break;
                            default:
                                if (opcion6 < 1 && opcion6 > 2) {
                                    System.out.println("Porfavor seleccione 1 o 2");
                                }
                                break;
                        }
                        break;
                    default:
                        if (opcion < 1 && opcion > 7) {
                            System.out.println("Porfavor insertar numeros entre el 1 y 7");
                        }
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Debe insertar un número!");
                sn.next();
            }

        } while (opcion != 7);
    }

    public static String leerString() throws IOException {
        Scanner hh = new Scanner(System.in);
        String variable = hh.nextLine();
        return variable;
    }

    public static int leerInt() throws IOException {
        Scanner hh = new Scanner(System.in);
        int variable = hh.nextInt();
        return variable;
    }

    public static void agregar(ColeccionSedes se) throws IOException {
        Votante vo = new Votante();
        System.out.println("Ingrese el nombre Completo del nuevo votante");
        String nombrePersona = leerString();
        vo.setNombrePersona(nombrePersona);
        System.out.println("Ingrese el RUT del votante");
        String rutPersona = leerString();
        vo.setRutPersona(rutPersona);
        System.out.println("Ingrese el nombre de la Calle o Avenida (Av) del votante");
        String calle = leerString();
        vo.setCallePersona(calle);
        System.out.println("Ingrese el número de domicilio del votante");
        String numero = leerString();
        vo.setNumeroCasaPersona(numero);
        System.out.println("¿Vocal de mesa, apoderado de mesa o ninguno?\n"
                + "1.- si el votante es vocal de mesa\n"
                + "2.- Si el votante es apoderado de mesa\n"
                + "3.- Si el votante no es ninguna de las anteriores");
        String esVocal = leerString();
        vo.setEsVocal(esVocal);
        if (se.agregar(vo, calle, numero, rutPersona, esVocal) == true) {
            System.out.println("Votante agregado con éxito");
        } else {
            System.out.println("Dirección mal ingresada o votante ya inscrito, revise los datos ingresados");
        }
    }

    private static void modificarCapacidadSede(ColeccionSedes cs) throws IOException {
        System.out.println("¿Para que Local de Votación quiere modificar su capacidad?\n"
                + "1.- Liceo de Limache\n"
                + "2.- Escuela Basica Brasilia\n"
                + "3.- Escuela N 49 Colegio Italiano\n"
                + "4.- Escuela Coeduc Teniente Hernán Merino Correa");
        String opcion = leerString();
        System.out.println("Ingrese la nueva capacidad del local");
        int capacidad = leerInt();
        if (cs.modificarCapSede(capacidad, opcion) == true) {
            System.out.println("Capacidad modificada con éxito");
        } 
    }

    private static void modificarDireccion(ColeccionSedes cs) throws IOException {
        System.out.println("¿Para que Local de Votación quiere modificar su dirección?\n"
                + "1.- Liceo de Limache\n"
                + "2.- Escuela Basica Brasilia\n"
                + "3.- Escuela N 49 Colegio Italiano\n"
                + "4.- Escuela Coeduc Teniente Hernán Merino Correa\n");
        String opcion = leerString();
        System.out.println("Ingrese la nueva dirección de la sede");
        String direccion = leerString();
        if (cs.modificarDireccion(direccion, opcion) == true) {
            System.out.println("Dirección modificada con éxito");
        }
    }

    private static void modificarNombre(ColeccionSedes cs) throws IOException {

        System.out.println("Ingrese el Rut del votante que desea modificar");
        String rutPersona = leerString();
        System.out.println("Ingrese nuevo nombre del votante");
        String nuevoNombre = leerString();
        if (cs.modificarNombre(rutPersona, nuevoNombre) == true) {
            System.out.println("Se ha modificado el nombre del votante con éxito");
        } else {
            System.out.println("ERROR!! Votante inexistente o datos redundantes, verifique los datos");
        }
    }

    private static void modificarRut(ColeccionSedes cs) throws IOException {
        System.out.println("Ingrese el Rut del votante que desea modificar");
        String rutPersona = leerString();
        System.out.println("Ingrese nuevo Rut del votante");
        String nuevoRut = leerString();
        if (cs.modificarRut(rutPersona, nuevoRut) == true) {
            System.out.println("Se ha modificado el rut del votante con éxito");
        } else {
            System.out.println("ERROR!! Votante inexistente o datos redundantes, verifique los datos");
        }
    }

    private static void modificarDireccionP(ColeccionSedes cs) throws IOException {
        System.out.println("Ingrese el Rut del votante que desea modificar");
        String rutPersona = leerString();
        System.out.println("Ingrese la nueva calle del votante");
        String nuevaUbi = leerString();
        System.out.println("Ingrese el nuevo número de casa del votante");
        String nuevoNum = leerString();
        if (cs.modificarDireccion(rutPersona, nuevaUbi,nuevoNum) == true) {
            System.out.println("Se ha modificado direccion del votante con éxito");
        } else {
            System.out.println("ERROR!! Votante inexistente o datos redundantes, verifique los datos");
        }
    }

    private static void modificarEsVocal(ColeccionSedes cs) throws IOException {
        System.out.println("Ingrese el Rut del vocal de mesa que desea modificar");
        String rutPersona = leerString();
        System.out.println("¿Vocal de mesa, apoderado de mesa o ninguno?\n"
                + "1.- si el votante es vocal de mesa\n"
                + "2.- Si el votante es apoderado de mesa\n"
                + "3.- Si el votante no es ninguna de las anteriores");
        String esVocal = leerString();
        if (cs.modificarEsVocal(rutPersona, esVocal) == true) {
            System.out.println("Se ha modificado el nombre del vocal con éxito");
        } else {
            System.out.println("Datos incorrectos o redundantes, verifique los datos");
        }
    }
    
    private static void eliminarP(ColeccionSedes cs) throws IOException {
        System.out.println("Ingrese el RUT del votante que desea eliminar");
        String rutPersona = leerString();
        if (cs.eliminar(rutPersona) == true) {
            System.out.println("Votante eliminado con éxito");
        } else {
            System.out.println("ERROR!! Datos incorrectos o redundantes, verifique los datos");
        }
    }
    
        private static void eliminar(ColeccionSedes cs) throws IOException {
        System.out.println("Ingrese el RUT del vocal de mesa que desea eliminar");
        String rutPersona = leerString();
        if (cs.eliminar(rutPersona) == true) {
            System.out.println("Votante eliminado con éxito");
        } else {
            System.out.println("ERROR!! Datos incorrectos o redundantes, verifique los datos");
        }
    }

    public static void mostrar(ColeccionSedes cs) throws IOException {
        cs.mostrar();
    }

    private static void mostrarP(ColeccionSedes cs) throws IOException {
        System.out.println("¿Para que Local de Votación quiere ver sus votantes??"
                + "1.- Liceo de Limache"
                + "2.- Escuela Basica Brasilia"
                + "3.- Escuela N 49 Colegio Italiano"
                + "4.- Escuela Coeduc Teniente Hernán Merino Correa");
        int opcion = leerInt();
        cs.mostrar(opcion);
    }
    private static void mostrarV(ColeccionSedes cs) throws IOException {
       System.out.println("Ingrese el RUT que desea consultar");
        String rutPersona = leerString();
        cs.mostrarV(rutPersona);
            
    }

    private static void menorPorcentaje(ColeccionSedes cs) throws IOException {
        cs.menorPorcentaje();
    }

    private static void porcentajeT(ColeccionSedes cs) throws IOException {
        System.out.println("¿Para que Local de Votación quiere calcular su Ocupación?"
                + "1.- Liceo de Limache"
                + "2.- Escuela Basica Brasilia"
                + "3.- Escuela N 49 Colegio Italiano"
                + "4.- Escuela Coeduc Teniente Hernán Merino Correa"
                + "Todos");
        String opcion = leerString();
        cs.porcentaje(opcion);
    }

    private static void capacitacionesV(ColeccionSedes cs) throws IOException {
        System.out.println("¿Para que Local de Votación quiere ver las capacitaciones de sus vocales?"
                + "1.- Liceo de Limache"
                + "2.- Escuela Basica Brasilia"
                + "3.- Escuela N 49 Colegio Italiano"
                + "4.- Escuela Coeduc Teniente Hernán Merino Correa");
        String opcion = leerString();
        cs.capacitacionesV(opcion);
    }

    private static void capacitacionesA(ColeccionSedes cs) throws IOException {
        System.out.println("¿Para que Local de Votación quiere ver las capacitaciones de sus vocales?"
                + "1.- Liceo de Limache"
                + "2.- Escuela Basica Brasilia"
                + "3.- Escuela N 49 Colegio Italiano"
                + "4.- Escuela Coeduc Teniente Hernán Merino Correa");
        String opcion = leerString();
        cs.capacitacionesA(opcion);
    }
}
